"""Bounded asynchronous intermediate TCP transport."""
from __future__ import annotations

import asyncio
import struct

from .errors import ProtocolError

MAX_FRAME = 16 * 1024 * 1024


class IntermediateTransport:
    def __init__(self, host: str, port: int = 443, timeout: float = 20) -> None:
        self.host, self.port, self.timeout = host, port, timeout
        self.reader: asyncio.StreamReader | None = None
        self.writer: asyncio.StreamWriter | None = None
        self._write_lock = asyncio.Lock()

    async def connect(self) -> None:
        self.reader, self.writer = await asyncio.wait_for(asyncio.open_connection(self.host, self.port), self.timeout)
        self.writer.write(b"\xee\xee\xee\xee")
        await self.writer.drain()

    async def send(self, data: bytes) -> None:
        if not self.writer or self.writer.is_closing():
            raise ConnectionError("Transport is disconnected")
        if not data or len(data) % 4 or len(data) > MAX_FRAME:
            raise ValueError("Invalid intermediate frame size")
        async with self._write_lock:
            self.writer.write(struct.pack("<I", len(data)) + data)
            await self.writer.drain()

    async def receive(self) -> bytes:
        if not self.reader:
            raise ConnectionError("Transport is disconnected")
        length = struct.unpack("<i", await self.reader.readexactly(4))[0]
        if length <= 0 or length % 4 or length > MAX_FRAME:
            raise ProtocolError(f"Invalid intermediate frame length: {length}")
        data = await self.reader.readexactly(length)
        if length == 4:
            raise ProtocolError(f"Telegram transport error: {struct.unpack('<i', data)[0]}")
        return data

    async def close(self) -> None:
        if self.writer:
            self.writer.close()
            try:
                await self.writer.wait_closed()
            except (OSError, ConnectionError):
                pass
        self.reader = self.writer = None
