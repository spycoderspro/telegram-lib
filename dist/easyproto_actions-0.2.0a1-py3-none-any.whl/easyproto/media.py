"""Chunked media transfers with bounded memory and atomic downloads."""
from __future__ import annotations

import asyncio
import hashlib
import mimetypes
import os
import tempfile
from pathlib import Path

from .client import Message, random_id
from .errors import UnsupportedFeature
from .tl import TLObject, functions, types

PART_SIZE = 512 * 1024


async def upload(client, path: str | Path) -> TLObject:
    path = Path(path)
    size = path.stat().st_size
    if not size:
        raise ValueError("Cannot upload an empty file")
    file_id = random_id()
    parts = (size + PART_SIZE - 1) // PART_SIZE
    big, digest = size > 10 * 1024 * 1024, hashlib.md5()
    with path.open("rb") as stream:
        for index in range(parts):
            chunk = await asyncio.to_thread(stream.read, PART_SIZE)
            if len(chunk) != min(PART_SIZE, size - index * PART_SIZE):
                raise OSError("Upload source changed during reading")
            digest.update(chunk)
            fields = dict(file_id=file_id, file_part=index, bytes=chunk)
            if big:
                fields["file_total_parts"] = parts
            result = await client.invoke(TLObject("upload.saveBigFilePart" if big else "upload.saveFilePart", **fields))
            if result is not True:
                raise OSError("Telegram did not accept the uploaded part")
        if stream.read(1):
            raise OSError("Upload source grew during reading")
    if big:
        return types.inputFileBig(id=file_id, parts=parts, name=path.name)
    return types.inputFile(id=file_id, parts=parts, name=path.name, md5_checksum=digest.hexdigest())


async def uploaded_media(client, path, as_photo: bool) -> TLObject:
    uploaded = await upload(client, path)
    if as_photo:
        return types.inputMediaUploadedPhoto(file=uploaded)
    return types.inputMediaUploadedDocument(file=uploaded,
        mime_type=mimetypes.guess_type(str(path))[0] or "application/octet-stream",
        attributes=[types.documentAttributeFilename(file_name=Path(path).name)])


async def send_media(client, target, path, *, caption: str = "", as_photo: bool = False, **options):
    peer = await client.resolve(target)
    if isinstance(path, (str, Path)):
        result = await client.invoke(functions.messages.sendMedia(peer=peer,
            media=await uploaded_media(client, path, as_photo), message=caption, random_id=random_id(), **options))
        return client._message(result, target, caption)
    paths = list(path)
    if not 2 <= len(paths) <= 10:
        raise ValueError("Albums require 2–10 files")
    album = []
    for index, item in enumerate(paths):
        uploaded = await client.invoke(functions.messages.uploadMedia(peer=peer, media=await uploaded_media(client, item, as_photo)))
        if uploaded.name == "messageMediaPhoto":
            photo = uploaded.photo
            value = types.inputMediaPhoto(id=types.inputPhoto(id=photo.id, access_hash=photo.access_hash, file_reference=photo.file_reference))
        elif uploaded.name == "messageMediaDocument":
            doc = uploaded.document
            value = types.inputMediaDocument(id=types.inputDocument(id=doc.id, access_hash=doc.access_hash, file_reference=doc.file_reference))
        else:
            raise UnsupportedFeature(f"Cannot add {uploaded.name} to an album")
        album.append(types.inputSingleMedia(media=value, random_id=random_id(), message=caption if index == 0 else ""))
    return await client.invoke(functions.messages.sendMultiMedia(peer=peer, multi_media=album, **options))


async def download(client, message: Message | TLObject, destination: str | Path = ".") -> Path:
    raw = message.raw if isinstance(message, Message) else message
    media = raw.get("media", raw)
    if not isinstance(media, TLObject):
        raise ValueError("Message has no downloadable media")
    if media.name == "messageMediaDocument" and media.get("document"):
        doc = media.document
        location = types.inputDocumentFileLocation(id=doc.id, access_hash=doc.access_hash,
                                                   file_reference=doc.file_reference, thumb_size="")
        name = next((a.file_name for a in doc.attributes if a.name == "documentAttributeFilename"), f"{doc.id}.bin")
        size, dc_id = doc.size, doc.dc_id
    elif media.name == "messageMediaPhoto" and media.get("photo"):
        photo = media.photo
        sizes = [s for s in photo.sizes if s.name in ("photoSize", "photoSizeProgressive")]
        if not sizes:
            raise UnsupportedFeature("Photo has no downloadable size")
        def photo_size(value):
            return value.get("size", max(value.get("sizes", [0])))
        largest = max(sizes, key=photo_size)
        location = types.inputPhotoFileLocation(id=photo.id, access_hash=photo.access_hash,
            file_reference=photo.file_reference, thumb_size=largest.type)
        size, dc_id, name = photo_size(largest), photo.dc_id, f"{photo.id}.jpg"
    else:
        raise UnsupportedFeature("Only document and photo downloads are implemented")
    requested = str(destination)
    destination = Path(destination)
    if destination.is_dir() or requested.endswith(os.sep):
        destination = destination / Path(name.replace("\\", "/")).name
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".easyproto-download-", dir=destination.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            async with client._at_dc(dc_id) as connection:
                offset = 0
                while offset < size:
                    result = await connection.invoke(functions.upload.getFile(location=location, offset=offset, limit=PART_SIZE))
                    if result.name != "upload.file":
                        raise UnsupportedFeature("CDN redirects are not implemented")
                    if not result.bytes or len(result.bytes) > size - offset:
                        raise OSError("Unexpected downloaded file size")
                    await asyncio.to_thread(stream.write, result.bytes)
                    offset += len(result.bytes)
        os.replace(temporary, destination)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return destination
