# Validation of the independent 0.2.0a1 rewrite

Validated in the current cloud machine on Python 3.12.14, PyCryptodome 4.1.0,
pytest 9.1.1 and pytest-asyncio 1.4.0. This supersedes the old Telethon-based
0.1.0 validation report.

## Passed

- 83 offline tests passed against the source installation.
- The same 83 tests passed against the built wheel in a separate virtual
  environment, using tests extracted from the built source distribution.
- Telethon and Pyrogram/Kurigram are absent from both new virtual environments.
  Runtime package metadata requires only PyCryptodome.
- All 2,628 registered TL declarations in the pinned official layer-232 schema
  encoded/decoded using synthetic minimal values. Real Telegram payload coverage
  is narrower; this is a codec check, not proof of live API compatibility.
- An AES-256-IGE known-answer vector matched OpenSSL libcrypto independently.
- A local server with a generated RSA private key completed the permanent auth-key
  handshake and derived the same shared key. Nonce, fingerprint, checksum and key
  confirmation tampering were rejected without retaining an authorization key.
- A separately computed SRP server proof matched the client's 2FA proof.
- An actual loopback TCP server exercised encrypted request/response framing,
  gzip-packed vector results inside a message container, RPC correlation and
  acknowledgements.
- Unit tests exercised message IDs, replay rejection, message authentication,
  bounds, server-salt corrections, future salts, session privacy/locking, login
  routing, cleanup, flood errors and no automatic mutation replay after a lost
  response.
- User-action request tests covered send/reply/scheduling, forwarding, deletion,
  invites, reactions, profile updates, entity caching, paginated history, media
  upload/send/download, raw calls and live-event filtering/cancellation.
- Wheel and source distribution built successfully. The wheel includes the native
  engine, vendored schemas, keys and upstream notices. The source archive includes
  the lockfile, complete offline tests/fixtures and examples. Neither archive
  contains account sessions.

## Blocked or unverified

An anonymous direct TCP connection to Telegram test DC 2 at
`149.154.167.40:443` was refused by the cloud machine (`ConnectionRefusedError`,
errno 111). The failure occurred before MTProto negotiation. No live protocol
success can be inferred from the local tests. HTTPS access to core.telegram.org
was also denied by the environment proxy; the official GitHub sources were
accessible.

No real Telegram login, account RPC, account event stream, DC migration, media
transfer or cross-DC authorization was validated. TG_API_ID, TG_API_HASH and
TG_SESSION were absent during setup; no account credentials were requested or
used, and no Telegram account messages were sent.

## Deliberate limitations

This is an experimental alpha, not full Telethon/Kurigram parity. It lacks an
independent security audit, automatic reconnect and update-state gap recovery,
HTML/Markdown parsing, CDN downloads, file-reference refresh, alternate/proxied
transports, signup and extra email/paid verification flows. Read README.md for
supported APIs and compatibility changes.

Before treating it as production-ready, validate real test-account login and 2FA,
Saved Messages actions, scheduled messages, upload/download and albums, entity
resolution, event handling, migration and failure recovery on a machine that can
reach Telegram MTProto. An independent cryptographic/protocol review is still
needed. Publishing a cloud snapshot or building the wheel does not perform these
checks.
